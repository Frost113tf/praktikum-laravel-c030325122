<?php $__env->startSection('konten'); ?>
    <article>
        <h2><?php echo e($artikel->judul); ?></h2>
        <p><strong>Penulis:</strong> <?php echo e($artikel->penulis->name ?? 'Anonim'); ?> | <strong>Status:</strong> <?php echo e(ucfirst($artikel->status)); ?></p>
        <p><small><strong>Tanggal Dibuat:</strong> <?php echo e($artikel->created_at->format('d M Y, H:i')); ?></small></p>
        <hr>
        <div style="margin-top: 20px; font-size: 1.1em;">
            <?php echo nl2br(e($artikel->isi)); ?>

        </div>
    </article>

    <div style="margin-top: 30px;">
        <a href="<?php echo e(route('artikel.edit', $artikel->id)); ?>" class="btn btn-warning">Edit Artikel Ini</a>
        <a href="<?php echo e(route('artikel.index')); ?>" class="btn btn-secondary">Kembali ke Daftar</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Praktikum Desainweb\praktikum-laravel-c030325122\praktikum-laravel-c030325122-sesi9\resources\views/artikel/show.blade.php ENDPATH**/ ?>
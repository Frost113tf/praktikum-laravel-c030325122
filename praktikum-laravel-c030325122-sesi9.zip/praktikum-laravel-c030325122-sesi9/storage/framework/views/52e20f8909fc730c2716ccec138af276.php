<?php $__env->startSection('konten'); ?>
    <h1>Tambah Artikel Baru</h1>

    
    <?php if($errors->any()): ?>
        <div style="background:#fee2e2; padding: 10px; margin-bottom: 15px; border-radius: 4px;">
            <ul style="margin: 0; color: #b91c1c;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('artikel.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Input Judul Artikel -->
        <div style="margin-bottom: 10px;">
            <label for="judul">Judul Artikel</label><br>
            <input type="text" name="judul" id="judul" value="<?php echo e(old('judul')); ?>" placeholder="Judul Artikel" style="width: 100%; padding: 8px;">
            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color:red;"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Input Isi Artikel -->
        <div style="margin-bottom: 10px;">
            <label for="isi">Isi Artikel</label><br>
            <textarea name="isi" id="isi" rows="5" placeholder="Isi Artikel" style="width: 100%; padding: 8px;"><?php echo e(old('isi')); ?></textarea>
            <?php $__errorArgs = ['isi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color:red;"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Pilihan Status Artikel -->
        <div style="margin-bottom: 10px;">
            <label for="status">Status Publikasi</label><br>
            <select name="status" id="status" style="width: 100%; padding: 8px;">
                <option value="draft" <?php echo e(old('status') == 'draft' ? 'selected' : ''); ?>>Draft</option>
                <option value="terbit" <?php echo e(old('status') == 'terbit' ? 'selected' : ''); ?>>Terbit</option>
            </select>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color:red;"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" style="padding: 10px 15px; background: #2563eb; color: white; border: none; border-radius: 4px;">Simpan Artikel</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Praktikum Desainweb\praktikum-laravel-c030325122\praktikum-laravel-c030325122-sesi9\resources\views/artikel/create.blade.php ENDPATH**/ ?>
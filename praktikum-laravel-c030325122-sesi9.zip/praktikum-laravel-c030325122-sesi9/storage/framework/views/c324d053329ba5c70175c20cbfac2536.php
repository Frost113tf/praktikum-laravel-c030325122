<?php $__env->startSection('konten'); ?>
    <h2>Daftar Artikel</h2>
    <a href="<?php echo e(route('artikel.create')); ?>" class="btn btn-primary" style="display: inline-block; margin-bottom: 15px;">+ Tambah Artikel Baru</a>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Status</th>
                <th>Penulis</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($artikel->firstItem() + $index); ?></td>
                    <td><?php echo e($item->judul); ?></td>
                    <td>
                        <span style="text-transform: capitalize; font-weight: bold; color: <?php echo e($item->status == 'terbit' ? 'green' : 'orange'); ?>">
                            <?php echo e($item->status); ?>

                        </span>
                    </td>
                    <td><?php echo e($item->penulis->name ?? 'Anonim'); ?></td>
                    <td>
                        <a href="<?php echo e(route('artikel.show', $item->id)); ?>" class="btn btn-secondary">Detail</a>
                        <a href="<?php echo e(route('artikel.edit', $item->id)); ?>" class="btn btn-warning">Edit</a>

                        <!-- Form Tombol Hapus -->
                        <form action="<?php echo e(route('artikel.destroy', $item->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin ingin menghapus artikel ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" style="text-align: center;">Belum ada artikel.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <div style="margin-top: 15px;">
        <?php echo e($artikel->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Praktikum Desainweb\praktikum-laravel-c030325122\praktikum-laravel-c030325122-sesi9\resources\views/artikel/index.blade.php ENDPATH**/ ?>
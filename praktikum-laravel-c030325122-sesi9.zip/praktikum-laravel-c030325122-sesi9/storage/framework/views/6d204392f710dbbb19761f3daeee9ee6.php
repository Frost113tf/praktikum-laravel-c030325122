


<?php $__env->startSection('konten'); ?>
<div style="max-width: 400px; margin: 0 auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px;">
    <h2 style="text-align: center;">Login</h2>

    <?php if($errors->any()): ?>
        <div style="color:red; margin-bottom: 10px; text-align: center;"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('login.post')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div style="margin-bottom: 15px;">
            <input type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" style="width: 100%; padding: 8px;" required>
        </div>
        <div style="margin-bottom: 15px;">
            <input type="password" name="password" placeholder="Password" style="width: 100%; padding: 8px;" required>
        </div>
        <button type="submit" style="width: 100%; padding: 10px; background-color: #2563eb; color: white; border: none; border-radius: 4px;">Login</button>
    </form>

    <p style="text-align: center; margin-top: 15px;">Belum punya akun? <a href="<?php echo e(route('register')); ?>">Daftar di sini</a></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Praktikum Desainweb\praktikum-laravel-c030325122\praktikum-laravel-c030325122-sesi9\resources\views/auth/login.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Manajemen Artikel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        nav { margin-bottom: 20px; padding: 10px; background: #f4f4f4; border-radius: 5px; }
        nav a { margin-right: 15px; text-decoration: none; color: #333; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table, th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #f8f9fa; }
        .alert-success { background: #d1fae5; color: #065f46; padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .btn { padding: 5px 10px; text-decoration: none; border-radius: 3px; cursor: pointer; border: none; }
        .btn-primary { background: #3b82f6; color: white; }
        .btn-warning { background: #f59e0b; color: white; }
        .btn-danger { background: #ef4444; color: white; }
        .btn-secondary { background: #6b7280; color: white; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input, .form-group textarea, .form-group select { width: 100%; padding: 8px; box-sizing: border-box; }
    </style>
</head>
<body>

    <!-- Navigasi Utama -->
    <nav>
        <a href="<?php echo e(route('artikel.index')); ?>">Daftar Artikel</a>
        <a href="<?php echo e(route('artikel.create')); ?>">+ Tambah Artikel</a>
    </nav>

    <nav>
    <a href="<?php echo e(route('artikel.index')); ?>">Kelola Artikel</a>
    <!-- Tautan navigasi lainnya -->
    </nav>

    <nav style="padding: 10px; background: #f3f4f6; margin-bottom: 20px;">
        <a href="<?php echo e(route('artikel.index')); ?>">Artikel</a>
    
        <?php if(auth()->guard()->check()): ?>
            <span style="margin-left: 20px;">Halo, <?php echo e(auth()->user()->name); ?></span>
            <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline; margin-left: 10px;">
                <?php echo csrf_field(); ?>
                <button type="submit" style="background: transparent; border: none; color: blue; cursor: pointer; text-decoration: underline;">Logout</button>
            </form>
        <?php else: ?>
            <span style="margin-left: 20px;">
                <a href="<?php echo e(route('login')); ?>">Login</a> | 
                <a href="<?php echo e(route('register')); ?>">Daftar</a>
            </span>
        <?php endif; ?>
    </nav>

    <!-- Flash Message / Pesan Konfirmasi -->
    <?php if(session('pesan')): ?>
        <div class="alert-success">
            <?php echo e(session('pesan')); ?>

        </div>
    <?php endif; ?>

    <!-- Konten Dinamis -->
    <div class="container">
        <?php echo $__env->yieldContent('konten'); ?>
    </div>

</body>
</html><?php /**PATH C:\Praktikum Desainweb\praktikum-laravel-c030325122\praktikum-laravel-c030325122-sesi9\resources\views/layouts/app.blade.php ENDPATH**/ ?>
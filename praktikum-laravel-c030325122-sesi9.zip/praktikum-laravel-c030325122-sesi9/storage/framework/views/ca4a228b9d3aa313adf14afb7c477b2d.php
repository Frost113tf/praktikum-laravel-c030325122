

<?php $__env->startSection('konten'); ?>
    <div style="max-width: 400px; margin: 0 auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px;">
        <h2 style="text-align: center;">Registrasi Akun Baru</h2>

        <form action="<?php echo e(url('/register')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <!-- Input Nama -->
            <div style="margin-bottom: 15px;">
                <label for="name">Nama Lengkap</label><br>
                <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="Masukkan nama" style="width: 100%; padding: 8px;" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color:red;"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Input Email -->
            <div style="margin-bottom: 15px;">
                <label for="email">Alamat Email</label><br>
                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="Masukkan email" style="width: 100%; padding: 8px;" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color:red;"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Input Password -->
            <div style="margin-bottom: 15px;">
                <label for="password">Password</label><br>
                <input type="password" name="password" id="password" placeholder="Minimal 8 karakter" style="width: 100%; padding: 8px;" required>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color:red;"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Input Konfirmasi Password -->
            <div style="margin-bottom: 20px;">
                <label for="password_confirmation">Konfirmasi Password</label><br>
                
                <input type="password" name="password_confirmation" id="password_confirmation" placeholder="Ketik ulang password" style="width: 100%; padding: 8px;" required>
            </div>

            <button type="submit" style="width: 100%; padding: 10px; background-color: #2563eb; color: white; border: none; border-radius: 4px; cursor: pointer;">
                Daftar
            </button>
        </form>
        
        <p style="text-align: center; margin-top: 15px;">
            Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Login di sini</a>
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Praktikum Desainweb\praktikum-laravel-c030325122\praktikum-laravel-c030325122-sesi9\resources\views/auth/register.blade.php ENDPATH**/ ?>
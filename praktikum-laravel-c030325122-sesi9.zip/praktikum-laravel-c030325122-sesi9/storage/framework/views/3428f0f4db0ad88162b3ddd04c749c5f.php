<?php $__env->startSection('konten'); ?>
    <h2>Edit Artikel</h2>

    <form action="<?php echo e(route('artikel.update', $artikel->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="judul">Judul Artikel:</label>
            <input type="text" id="judul" name="judul" value="<?php echo e($artikel->judul); ?>" required>
        </div>

        <div class="form-group">
            <label for="isi">Isi Artikel:</label>
            <textarea id="isi" name="isi" rows="6" required><?php echo e($artikel->isi); ?></textarea>
        </div>

        <div class="form-group">
            <label for="status">Status Publikasi:</label>
            <select id="status" name="status" required>
                <option value="draft" <?php echo e($artikel->status == 'draft' ? 'selected' : ''); ?>>Draft</option>
                <option value="terbit" <?php echo e($artikel->status == 'terbit' ? 'selected' : ''); ?>>Terbit</option>
            </select>
        </div>

        <button type="submit" class="btn btn-warning">Perbarui Artikel</button>
        <a href="<?php echo e(route('artikel.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Praktikum Desainweb\praktikum-laravel-c030325122\praktikum-laravel-c030325122-sesi9\resources\views/artikel/edit.blade.php ENDPATH**/ ?>